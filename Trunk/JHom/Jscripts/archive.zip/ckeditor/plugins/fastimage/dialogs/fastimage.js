﻿/**
 * @license Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.html or http://ckeditor.com/license
 */

(function() {
	var imageDialog = function( editor, dialogType ) {};

	CKEDITOR.dialog.add( 'fastimage', function( editor ) {
	});

	CKEDITOR.dialog.add( 'imagebutton', function( editor ) {
	});
})();
