﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'fastimage', 'fr', {
	title: 'Ajouter une image',
	noFileSelected: 'Aucun fichier sélectionné',
	maxSizeMessage: 'La taille de l\'image ne doit pas dépasser % Mo',
	invalidWidth: 'La longueur doit être un entier supérieur à 0',
	invalidHeight: 'La hauteur doit être un entier supérieur à 0'
});
